<?php

header('location:admin');

?>